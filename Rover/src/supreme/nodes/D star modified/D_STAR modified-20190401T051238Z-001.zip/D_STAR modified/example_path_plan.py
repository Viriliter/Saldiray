from d_star import DStar
import numpy
import numpy as np

# setting start and end points /// start position: from gps , goal: from user
# goal_x = input ("Enter x coordinate: (goal)")
# goalx = float(goal_x)
# goal_y = input ("Enter y coordinate: (goal)")
# goaly = float(goal_y)

var1, var2 = [float(x) for x in input("Enter goal coordinates(x,y) here: ").split()]

pf = DStar(x_start=0, y_start=0, x_goal=var1, y_goal=var2)

var = 1

# create empty matrix // gerek kalmayabilir
a = numpy.zeros(shape=(500000,500000))

while (var == 1)

# read matrix from file
a = np.loadtxt("input.txt", dtype='i', delimiter=',')

    for i in range(len(a)):
        for j in range(len(a[i])):
            if (a[i][j] == 1)
                    pf.update_cell(i, j, -1)
            else
                    pf.update_cell(i, j, 0)

    pf.replan()
    path = pf.get_path()

    # update start point for next cycle // gpsten input alarak update et!!!
    pf.update_start(x, y)